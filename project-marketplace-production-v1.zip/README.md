# Project Marketplace — Production Preparation

## Included
- Customer/provider/admin authentication with scrypt password hashing
- Token-based authenticated API sessions
- Service requests, quotes, bookings
- Provider job management
- Customer/provider messaging and notifications
- Reviews and ratings
- Paystack transaction initialization, verification and webhook support
- Admin dashboard and business verification
- Basic API rate limiting and HTTP security headers
- Environment-based configuration

## Local development
```bash
npm install
cp .env.example .env
# Set NODE_ENV=development and use your local values.
npm start
```
Open `http://localhost:3000/`.

## Production configuration
Set:
- `NODE_ENV=production`
- `CORS_ORIGIN` to your exact frontend origin(s), comma-separated
- `PUBLIC_BASE_URL` to the public HTTPS URL
- `PAYSTACK_SECRET_KEY` as a server-only secret
- `ADMIN_EMAIL` and a strong `ADMIN_PASSWORD`
- `RATE_LIMIT_PER_MINUTE` as appropriate for your traffic

Do not commit `.env` or any secret key to source control.

## Paystack webhook
Configure Paystack to send events to:
`https://YOUR_DOMAIN/api/paystack/webhook`

The webhook validates the `x-paystack-signature` HMAC, checks the payment reference, amount and NGN currency, and processes successful charges idempotently.

## Production database
The MVP currently uses SQLite for portability. Before a high-traffic launch, migrate to PostgreSQL and add automated backups, connection pooling, migrations, monitoring and restore testing.

## Deployment checklist
- Use HTTPS only.
- Store secrets in the hosting provider's secret/environment manager.
- Restrict CORS to your real frontend origin(s).
- Configure Paystack webhook URL.
- Use a managed PostgreSQL database for production scale.
- Add automated database backups.
- Add centralized logs and uptime/error monitoring.
- Run dependency audits and keep Node/dependencies patched.
- Complete KYC/business verification requirements before onboarding providers at scale.
