import express from 'express';
import cors from 'cors';
import Database from 'better-sqlite3';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const db = new Database(path.join(__dirname, 'marketplace.db'));
const isProduction = process.env.NODE_ENV === 'production';
const allowedOrigin = process.env.CORS_ORIGIN || '';
app.disable('x-powered-by');
app.use((req,res,next)=>{
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
  if(isProduction) res.setHeader('Strict-Transport-Security','max-age=31536000; includeSubDomains');
  next();
});
app.use(cors({origin:(origin,cb)=>{
  if(!origin || !allowedOrigin || allowedOrigin.split(',').map(x=>x.trim()).includes(origin)) return cb(null,true);
  return cb(new Error('CORS origin not allowed'));
}, credentials:false, methods:['GET','POST','PATCH','DELETE','OPTIONS'], allowedHeaders:['Content-Type','Authorization','X-Requested-With']}));
app.use(express.json({limit:'256kb', strict:true}));
app.use(express.static(__dirname, {dotfiles:'ignore', index:'index.html'}));

const requestHits = new Map();
const RATE_WINDOW = 60_000;
const RATE_LIMIT = Number(process.env.RATE_LIMIT_PER_MINUTE || 120);
function rateLimit(req,res,next){
  if(!req.path.startsWith('/api/')) return next();
  const key = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  let hit = requestHits.get(key);
  if(!hit || now-hit.started >= RATE_WINDOW) hit={started:now,count:0};
  hit.count++; requestHits.set(key,hit);
  if(hit.count>RATE_LIMIT) return res.status(429).json({error:'Too many requests. Please try again shortly.'});
  next();
}
app.use(rateLimit);
setInterval(()=>{const cutoff=Date.now()-RATE_WINDOW; for(const [k,v] of requestHits) if(v.started<cutoff) requestHits.delete(k);}, RATE_WINDOW).unref();

db.exec(`PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL CHECK(role IN ('customer','provider','admin')), name TEXT NOT NULL, email TEXT UNIQUE, phone TEXT UNIQUE, password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS businesses (id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL REFERENCES users(id), name TEXT NOT NULL, category TEXT, description TEXT, city TEXT, address TEXT, verified INTEGER NOT NULL DEFAULT 0, rating REAL NOT NULL DEFAULT 0, review_count INTEGER NOT NULL DEFAULT 0, available INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS services (id INTEGER PRIMARY KEY AUTOINCREMENT, business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE, name TEXT NOT NULL, price_from INTEGER, description TEXT);
CREATE TABLE IF NOT EXISTS requests (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL REFERENCES users(id), category TEXT, title TEXT NOT NULL, description TEXT NOT NULL, city TEXT, address TEXT, urgency TEXT DEFAULT 'flexible', budget INTEGER, status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS quotes (id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER NOT NULL REFERENCES requests(id) ON DELETE CASCADE, business_id INTEGER NOT NULL REFERENCES businesses(id), amount INTEGER NOT NULL, message TEXT, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS bookings (id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER NOT NULL REFERENCES requests(id), quote_id INTEGER NOT NULL REFERENCES quotes(id), customer_id INTEGER NOT NULL REFERENCES users(id), business_id INTEGER NOT NULL REFERENCES businesses(id), scheduled_at TEXT, address TEXT, status TEXT NOT NULL DEFAULT 'confirmed', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS reviews (id INTEGER PRIMARY KEY AUTOINCREMENT, booking_id INTEGER NOT NULL REFERENCES bookings(id), customer_id INTEGER NOT NULL REFERENCES users(id), business_id INTEGER NOT NULL REFERENCES businesses(id), rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5), comment TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY AUTOINCREMENT, booking_id INTEGER NOT NULL UNIQUE REFERENCES bookings(id) ON DELETE CASCADE, customer_id INTEGER NOT NULL REFERENCES users(id), business_id INTEGER NOT NULL REFERENCES businesses(id), amount INTEGER NOT NULL, currency TEXT NOT NULL DEFAULT 'NGN', provider TEXT NOT NULL DEFAULT 'demo', reference TEXT NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'pending', paid_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS conversations (id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, provider_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, request_id INTEGER REFERENCES requests(id) ON DELETE SET NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(customer_id, provider_id, request_id));
CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE, sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, body TEXT NOT NULL, read_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, type TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, link TEXT, read_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_business_category_city ON businesses(category, city); CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status); CREATE INDEX IF NOT EXISTS idx_quotes_request ON quotes(request_id); CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);`);
// Payment gateway metadata columns (safe for existing SQLite databases).
try { db.exec("ALTER TABLE payments ADD COLUMN access_code TEXT"); } catch {}
try { db.exec("ALTER TABLE payments ADD COLUMN gateway_status TEXT"); } catch {}
const q=sql=>db.prepare(sql); const normalizeEmail=v=>String(v||'').trim().toLowerCase();
function hashPassword(password){const salt=crypto.randomBytes(16).toString('hex'); return salt+':'+crypto.scryptSync(String(password),salt,64).toString('hex');}
function verifyPassword(password,stored){const [salt,hash]=String(stored||'').split(':'); if(!salt||!hash)return false; const b=crypto.scryptSync(String(password),salt,64); return crypto.timingSafeEqual(b,Buffer.from(hash,'hex'));}
function token(){return crypto.randomBytes(32).toString('hex')} function tokenHash(t){return crypto.createHash('sha256').update(t).digest('hex')}
function auth(req,res,next){const t=(req.headers.authorization||'').replace(/^Bearer\s+/i,''); if(!t)return res.status(401).json({error:'Authentication required'}); const s=q(`SELECT s.*,u.id user_id,u.name,u.email,u.phone,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?`).get(tokenHash(t),Date.now()); if(!s)return res.status(401).json({error:'Session expired or invalid'}); req.user={id:s.user_id,name:s.name,email:s.email,phone:s.phone,role:s.role}; req.token=t; next();}
const role=(...roles)=>(req,res,next)=>roles.includes(req.user.role)?next():res.status(403).json({error:'You do not have permission for this action'});

app.get('/api/health',(_,res)=>res.json({ok:true,service:'Project Marketplace API'}));
app.post('/api/auth/register',(req,res)=>{const {name,email,phone,password,role='customer'}=req.body; if(!name||!password||(!email&&!phone))return res.status(400).json({error:'Name, password and email or phone are required'}); if(!['customer','provider'].includes(role))return res.status(400).json({error:'Invalid role'}); if(String(password).length<8)return res.status(400).json({error:'Password must be at least 8 characters'}); try{const info=q('INSERT INTO users(role,name,email,phone,password_hash) VALUES(?,?,?,?,?)').run(role,String(name).trim(),email?normalizeEmail(email):null,phone?String(phone).trim():null,hashPassword(password)); const u=q('SELECT id,name,email,phone,role,created_at FROM users WHERE id=?').get(info.lastInsertRowid); if(role==='provider')q('INSERT INTO businesses(owner_id,name,city) VALUES(?,?,?)').run(u.id,`${u.name}'s Business`,'Abuja'); const t=token(); q('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').run(tokenHash(t),u.id,Date.now()+2592000000); res.status(201).json({token:t,user:u});}catch(e){const m=String(e.message);res.status(400).json({error:m.includes('users.email')?'Email already registered':m.includes('users.phone')?'Phone already registered':'Registration failed'});}});
app.post('/api/auth/login',(req,res)=>{const id=String(req.body.identifier||'').trim(),password=String(req.body.password||''); const u=q('SELECT * FROM users WHERE email=? OR phone=?').get(normalizeEmail(id),id); if(!u||!verifyPassword(password,u.password_hash))return res.status(401).json({error:'Invalid login details'}); const t=token(); q('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').run(tokenHash(t),u.id,Date.now()+2592000000); res.json({token:t,user:{id:u.id,name:u.name,email:u.email,phone:u.phone,role:u.role}});});
app.post('/api/auth/logout',auth,(req,res)=>{q('DELETE FROM sessions WHERE token_hash=?').run(tokenHash(req.token));res.json({ok:true})}); app.get('/api/auth/me',auth,(req,res)=>res.json({user:req.user}));
app.get('/api/customer/dashboard',auth,role('customer'),(req,res)=>{const requests=q(`SELECT r.*, (SELECT COUNT(*) FROM quotes q WHERE q.request_id=r.id) quote_count FROM requests r WHERE r.customer_id=? ORDER BY r.created_at DESC`).all(req.user.id);const bookings=q('SELECT b.*,q.amount,biz.name business_name,r.title,(SELECT id FROM reviews rv WHERE rv.booking_id=b.id LIMIT 1) review_id,(SELECT rating FROM reviews rv WHERE rv.booking_id=b.id LIMIT 1) review_rating,(SELECT status FROM payments p WHERE p.booking_id=b.id LIMIT 1) payment_status,(SELECT reference FROM payments p WHERE p.booking_id=b.id LIMIT 1) payment_reference FROM bookings b JOIN quotes q ON q.id=b.quote_id JOIN businesses biz ON biz.id=b.business_id JOIN requests r ON r.id=b.request_id WHERE b.customer_id=? ORDER BY b.created_at DESC').all(req.user.id);res.json({user:req.user,requests,bookings})});
app.get('/api/provider/dashboard',auth,role('provider'),(req,res)=>{const business=q('SELECT * FROM businesses WHERE owner_id=?').get(req.user.id);const requests=q(`SELECT r.*,q.id quote_id,q.amount quote_amount FROM requests r LEFT JOIN quotes q ON q.request_id=r.id AND q.business_id=? WHERE r.status IN ('open','booked') ORDER BY r.created_at DESC`).all(business.id);const bookings=q('SELECT b.*,q.amount,r.title,(SELECT status FROM payments p WHERE p.booking_id=b.id LIMIT 1) payment_status FROM bookings b JOIN quotes q ON q.id=b.quote_id JOIN requests r ON r.id=b.request_id WHERE b.business_id=? ORDER BY b.created_at DESC').all(business.id);res.json({user:req.user,business,requests,bookings})});
app.get('/api/providers',(req,res)=>{const category=req.query.category||'',city=req.query.city||'',term=req.query.q||'';let sql='SELECT b.*,u.name owner_name FROM businesses b JOIN users u ON u.id=b.owner_id WHERE 1=1',a=[];if(category){sql+=' AND (b.category LIKE ? OR EXISTS(SELECT 1 FROM services s WHERE s.business_id=b.id AND s.name LIKE ?))';a.push('%'+category+'%','%'+category+'%')}if(city){sql+=' AND b.city LIKE ?';a.push('%'+city+'%')}if(term){sql+=' AND (b.name LIKE ? OR b.description LIKE ? OR b.category LIKE ? OR EXISTS(SELECT 1 FROM services s WHERE s.business_id=b.id AND s.name LIKE ?))';a.push(...Array(4).fill('%'+term+'%'))}sql+=' ORDER BY b.verified DESC,b.rating DESC,b.review_count DESC LIMIT 50';res.json(q(sql).all(...a))});
app.get('/api/providers/:id/reviews',(req,res)=>{
  const rows=q(`SELECT rv.id,rv.rating,rv.comment,rv.created_at,u.name customer_name FROM reviews rv JOIN users u ON u.id=rv.customer_id WHERE rv.business_id=? ORDER BY rv.created_at DESC LIMIT 50`).all(req.params.id);
  res.json(rows);
});

app.get('/api/bookings/:id/review',auth,role('customer'),(req,res)=>{
  const b=q('SELECT * FROM bookings WHERE id=? AND customer_id=?').get(req.params.id,req.user.id);
  if(!b)return res.status(404).json({error:'Booking not found'});
  const review=q('SELECT * FROM reviews WHERE booking_id=?').get(b.id);
  res.json({review:review||null,booking:b});
});

app.post('/api/bookings/:id/review',auth,role('customer'),(req,res)=>{
  const rating=Number(req.body.rating),comment=String(req.body.comment||'').trim();
  if(!Number.isInteger(rating)||rating<1||rating>5)return res.status(400).json({error:'Rating must be an integer from 1 to 5'});
  if(comment.length>1000)return res.status(400).json({error:'Review is too long'});
  const b=q('SELECT * FROM bookings WHERE id=? AND customer_id=?').get(req.params.id,req.user.id);
  if(!b)return res.status(404).json({error:'Booking not found'});
  if(b.status!=='completed')return res.status(400).json({error:'You can review a booking only after it is completed'});
  if(q('SELECT id FROM reviews WHERE booking_id=?').get(b.id))return res.status(409).json({error:'You already reviewed this booking'});
  const tx=db.transaction(()=>{
    const info=q('INSERT INTO reviews(booking_id,customer_id,business_id,rating,comment) VALUES(?,?,?,?,?)').run(b.id,req.user.id,b.business_id,rating,comment||null);
    const stats=q('SELECT ROUND(AVG(rating),1) rating,COUNT(*) review_count FROM reviews WHERE business_id=?').get(b.business_id);
    q('UPDATE businesses SET rating=?,review_count=? WHERE id=?').run(stats.rating||0,stats.review_count||0,b.business_id);
    const biz=q('SELECT owner_id,name FROM businesses WHERE id=?').get(b.business_id);
    notify(biz.owner_id,'review','New customer review',`${req.user.name} rated ${biz.name} ${rating}/5`,`provider-dashboard.html`);
    return info.lastInsertRowid;
  });
  const id=tx();
  res.status(201).json({id,rating,comment,ok:true});
});

app.get('/api/providers/:id',(req,res)=>{const b=q('SELECT b.*,u.name owner_name,u.phone,u.email FROM businesses b JOIN users u ON u.id=b.owner_id WHERE b.id=?').get(req.params.id);if(!b)return res.status(404).json({error:'Provider not found'});b.services=q('SELECT * FROM services WHERE business_id=?').all(b.id);res.json(b)});
app.post('/api/requests',auth,role('customer'),(req,res)=>{const {category,title,description,city,address,urgency,budget}=req.body;if(!title||!description)return res.status(400).json({error:'Title and description are required'});const i=q('INSERT INTO requests(customer_id,category,title,description,city,address,urgency,budget) VALUES(?,?,?,?,?,?,?,?)').run(req.user.id,category||null,title,description,city||null,address||null,urgency||'flexible',budget||null);res.status(201).json({id:i.lastInsertRowid,status:'open'})});
app.get('/api/requests/:id/quotes',auth,(req,res)=>{const r=q('SELECT * FROM requests WHERE id=?').get(req.params.id);if(!r)return res.status(404).json({error:'Request not found'});if(req.user.role==='customer'&&r.customer_id!==req.user.id)return res.status(403).json({error:'Forbidden'});res.json(q('SELECT q.*,b.name business_name,b.city,b.rating,b.verified FROM quotes q JOIN businesses b ON b.id=q.business_id WHERE q.request_id=? ORDER BY q.amount ASC').all(req.params.id))});
app.post('/api/quotes',auth,role('provider'),(req,res)=>{const {request_id,amount,message}=req.body,b=q('SELECT * FROM businesses WHERE owner_id=?').get(req.user.id),r=q('SELECT * FROM requests WHERE id=?').get(request_id);if(!b||!r)return res.status(404).json({error:'Request or provider not found'});if(r.status!=='open')return res.status(400).json({error:'This request is no longer open for quotes'});if(!Number.isFinite(Number(amount))||Number(amount)<=0)return res.status(400).json({error:'Amount must be greater than zero'});const existing=q('SELECT id FROM quotes WHERE request_id=? AND business_id=?').get(request_id,b.id);if(existing)return res.status(409).json({error:'You already sent a quote for this request'});const i=q('INSERT INTO quotes(request_id,business_id,amount,message) VALUES(?,?,?,?)').run(request_id,b.id,Number(amount),message||null);notify(r.customer_id,'quote','New quote received',`${b.name} sent a quote of ${Number(amount).toLocaleString()}`,`quotes.html?request=${request_id}`);res.status(201).json({id:i.lastInsertRowid,status:'pending'})});
app.patch('/api/bookings/:id/status',auth,role('provider'),(req,res)=>{const status=String(req.body.status||'').trim();const allowed=['confirmed','in_progress','completed','cancelled'];if(!allowed.includes(status))return res.status(400).json({error:'Invalid booking status'});const b=q(`SELECT b.*,r.title,r.customer_id FROM bookings b JOIN requests r ON r.id=b.request_id JOIN businesses biz ON biz.id=b.business_id WHERE b.id=? AND biz.owner_id=?`).get(req.params.id,req.user.id);if(!b)return res.status(404).json({error:'Booking not found'});if(b.status==='cancelled'&&status!=='cancelled')return res.status(400).json({error:'Cancelled bookings cannot be reopened'});const payment=q("SELECT status FROM payments WHERE booking_id=?").get(b.id);if(status!=='cancelled'&&(!payment||payment.status!=='paid'))return res.status(400).json({error:'Customer payment is required before starting this job'});q('UPDATE bookings SET status=? WHERE id=?').run(status,b.id);notify(b.customer_id,'booking','Booking status updated',`${b.title}: ${status.replace('_',' ')}`,`booking.html?id=${b.id}`);res.json({ok:true,status});});
app.post('/api/bookings',auth,role('customer'),(req,res)=>{const {request_id,quote_id,scheduled_at,address}=req.body,r=q('SELECT * FROM requests WHERE id=?').get(request_id),qt=q('SELECT * FROM quotes WHERE id=?').get(quote_id);if(!r||r.customer_id!==req.user.id)return res.status(403).json({error:'Invalid request'});if(r.status!=='open')return res.status(400).json({error:'This request has already been booked'});if(!qt||qt.request_id!==Number(request_id)||qt.status!=='pending')return res.status(400).json({error:'Invalid or unavailable quote'});const i=q('INSERT INTO bookings(request_id,quote_id,customer_id,business_id,scheduled_at,address,status) VALUES(?,?,?,?,?,?,?)').run(request_id,quote_id,req.user.id,qt.business_id,scheduled_at||null,address||r.address||null,'payment_pending');q("UPDATE quotes SET status='accepted' WHERE id=?").run(quote_id);q("UPDATE quotes SET status='rejected' WHERE request_id=? AND id<>? AND status='pending'").run(request_id,quote_id);q("UPDATE requests SET status='booked' WHERE id=?").run(request_id);const biz=q('SELECT name,owner_id FROM businesses WHERE id=?').get(qt.business_id);notify(biz.owner_id,'booking','Booking confirmed',`A customer accepted your quote for ${r.title}`,`provider-dashboard.html`);const paymentRef='PM_'+Date.now().toString(36).toUpperCase()+'_'+crypto.randomBytes(4).toString('hex').toUpperCase();q('INSERT INTO payments(booking_id,customer_id,business_id,amount,reference) VALUES(?,?,?,?,?)').run(i.lastInsertRowid,req.user.id,qt.business_id,qt.amount,paymentRef);res.status(201).json({id:i.lastInsertRowid,status:'pending_payment',amount:qt.amount,currency:'NGN',reference:paymentRef,payment_required:true})});
app.get('/api/payments/:id',auth,role('customer'),(req,res)=>{const p=q(`SELECT p.*,b.scheduled_at,b.address,r.title,biz.name business_name FROM payments p JOIN bookings b ON b.id=p.booking_id JOIN requests r ON r.id=b.request_id JOIN businesses biz ON biz.id=b.business_id WHERE p.id=? AND p.customer_id=?`).get(req.params.id,req.user.id);if(!p)return res.status(404).json({error:'Payment not found'});res.json(p);});
app.get('/api/bookings/:id/payment',auth,role('customer'),(req,res)=>{const p=q('SELECT p.*,b.status booking_status FROM payments p JOIN bookings b ON b.id=p.booking_id WHERE p.booking_id=? AND p.customer_id=?').get(req.params.id,req.user.id);if(!p)return res.status(404).json({error:'Payment not found'});res.json(p);});
app.post('/api/bookings/:id/pay',auth,role('customer'),async(req,res)=>{
  const p=q('SELECT p.*,b.status booking_status,b.customer_id,b.business_id,r.title FROM payments p JOIN bookings b ON b.id=p.booking_id JOIN requests r ON r.id=b.request_id WHERE p.booking_id=? AND p.customer_id=?').get(req.params.id,req.user.id);
  if(!p)return res.status(404).json({error:'Booking payment not found'});
  if(p.status==='paid')return res.json({ok:true,status:'paid',reference:p.reference});
  if(p.booking_status==='cancelled')return res.status(400).json({error:'Cancelled bookings cannot be paid'});
  if(!process.env.PAYSTACK_SECRET_KEY)return res.status(503).json({error:'Paystack is not configured. Set PAYSTACK_SECRET_KEY on the server.'});
  if(!req.user.email)return res.status(400).json({error:'A valid customer email is required for Paystack payment.'});
  try {
    const base=(process.env.PUBLIC_BASE_URL||`${req.protocol}://${req.get('host')}`).replace(/\/$/,'');
    const response=await fetch('https://api.paystack.co/transaction/initialize',{method:'POST',headers:{Authorization:`Bearer ${process.env.PAYSTACK_SECRET_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({
      email:req.user.email, amount:String(Number(p.amount)*100), currency:'NGN', reference:p.reference,
      callback_url:`${base}/payment.html?booking=${p.booking_id}`,
      metadata:{booking_id:p.booking_id,customer_id:p.customer_id,business_id:p.business_id}
    })});
    const data=await response.json();
    if(!response.ok || !data.status) return res.status(502).json({error:data.message||'Unable to initialize Paystack transaction'});
    q(`UPDATE payments SET provider='paystack',access_code=?,gateway_status='initialized' WHERE id=?`).run(data.data.access_code,p.id);
    res.json({ok:true,provider:'paystack',reference:p.reference,access_code:data.data.access_code,authorization_url:data.data.authorization_url});
  } catch(e) { res.status(502).json({error:'Unable to reach Paystack'}); }
});

app.post('/api/bookings/:id/paystack/verify',auth,role('customer'),async(req,res)=>{
  const reference=String(req.body.reference||'').trim();
  const p=q('SELECT p.*,b.status booking_status,b.customer_id,b.business_id,r.title FROM payments p JOIN bookings b ON b.id=p.booking_id JOIN requests r ON r.id=b.request_id WHERE p.booking_id=? AND p.customer_id=?').get(req.params.id,req.user.id);
  if(!p)return res.status(404).json({error:'Booking payment not found'});
  if(p.status==='paid')return res.json({ok:true,status:'paid',reference:p.reference});
  if(!process.env.PAYSTACK_SECRET_KEY)return res.status(503).json({error:'Paystack is not configured on the server.'});
  if(!reference || reference!==p.reference)return res.status(400).json({error:'Invalid payment reference'});
  try {
    const response=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{headers:{Authorization:`Bearer ${process.env.PAYSTACK_SECRET_KEY}`} });
    const data=await response.json();
    if(!response.ok || !data.status)return res.status(502).json({error:data.message||'Unable to verify Paystack transaction'});
    const tx=data.data;
    q('UPDATE payments SET gateway_status=? WHERE id=?').run(tx.status,p.id);
    if(tx.status!=='success')return res.status(400).json({error:`Payment status is ${tx.status}`});
    if(Number(tx.amount)!==Number(p.amount)*100 || String(tx.currency||'NGN').toUpperCase()!=='NGN')return res.status(400).json({error:'Payment amount or currency does not match the booking'});
    const owner=q('SELECT owner_id FROM businesses WHERE id=?').get(p.business_id);
    db.transaction(()=>{
      q("UPDATE payments SET status='paid',paid_at=COALESCE(?,CURRENT_TIMESTAMP),provider='paystack',gateway_status='success' WHERE id=? AND status<>'paid'").run(tx.paid_at||null,p.id);
      q("UPDATE bookings SET status='confirmed' WHERE id=? AND status='payment_pending'").run(p.booking_id);
      if(owner) notify(owner.owner_id,'payment','Payment received',`Payment received for ${p.title}`,`provider-dashboard.html`);
    })();
    res.json({ok:true,status:'paid',reference:p.reference});
  } catch(e) { res.status(502).json({error:'Unable to verify payment with Paystack'}); }
});

// Paystack webhook: signature-validated, idempotent successful-charge fulfillment.
app.post('/api/paystack/webhook',(req,res)=>{
  const secret=process.env.PAYSTACK_SECRET_KEY;
  const signature=String(req.headers['x-paystack-signature']||'');
  if(!secret || !signature) return res.sendStatus(401);
  const expected=crypto.createHmac('sha512',secret).update(JSON.stringify(req.body)).digest('hex');
  const expectedBuf=Buffer.from(expected,'utf8'); const signatureBuf=Buffer.from(signature,'utf8');
  if(expectedBuf.length!==signatureBuf.length || !crypto.timingSafeEqual(expectedBuf,signatureBuf)) return res.sendStatus(401);
  res.sendStatus(200);
  try {
    if(req.body?.event!=='charge.success') return;
    const tx=req.body.data||{}; const reference=String(tx.reference||'');
    const p=q('SELECT * FROM payments WHERE reference=?').get(reference); if(!p || p.status==='paid') return;
    if(Number(tx.amount)!==Number(p.amount)*100 || String(tx.currency||'NGN').toUpperCase()!=='NGN') return;
    const owner=q('SELECT owner_id FROM businesses WHERE id=?').get(p.business_id);
    const booking=q('SELECT b.status,r.title FROM bookings b JOIN requests r ON r.id=b.request_id WHERE b.id=?').get(p.booking_id);
    if(!booking || booking.status==='cancelled') return;
    db.transaction(()=>{
      q("UPDATE payments SET status='paid',paid_at=COALESCE(?,CURRENT_TIMESTAMP),provider='paystack',gateway_status='success' WHERE id=? AND status<>'paid'").run(tx.paid_at||null,p.id);
      q("UPDATE bookings SET status='confirmed' WHERE id=? AND status='payment_pending'").run(p.booking_id,p.booking_id);
      if(owner) notify(owner.owner_id,'payment','Payment received',`Payment received for ${booking.title}`,`provider-dashboard.html`);
    })();
  } catch {}
});

app.get('/api/payments',auth,role('customer'),(req,res)=>{res.json(q(`SELECT p.*,r.title,b.status booking_status,b.scheduled_at,biz.name business_name FROM payments p JOIN bookings b ON b.id=p.booking_id JOIN requests r ON r.id=b.request_id JOIN businesses biz ON biz.id=b.business_id WHERE p.customer_id=? ORDER BY p.created_at DESC`).all(req.user.id));});
app.get('/api/admin/stats',auth,role('admin'),(req,res)=>{
  const one=(sql)=>q(sql).get();
  res.json({
    users: one("SELECT COUNT(*) count FROM users").count,
    customers: one("SELECT COUNT(*) count FROM users WHERE role='customer'").count,
    providers: one("SELECT COUNT(*) count FROM users WHERE role='provider'").count,
    businesses: one("SELECT COUNT(*) count FROM businesses").count,
    verified_businesses: one("SELECT COUNT(*) count FROM businesses WHERE verified=1").count,
    open_requests: one("SELECT COUNT(*) count FROM requests WHERE status='open'").count,
    bookings: one("SELECT COUNT(*) count FROM bookings").count,
    completed_bookings: one("SELECT COUNT(*) count FROM bookings WHERE status='completed'").count,
    payments: one("SELECT COUNT(*) count FROM payments WHERE status='paid'").count,
    revenue: one("SELECT COALESCE(SUM(amount),0) total FROM payments WHERE status='paid'").total,
    reviews: one("SELECT COUNT(*) count FROM reviews").count
  });
});
app.get('/api/admin/users',auth,role('admin'),(req,res)=>{
  res.json(q(`SELECT id,name,email,phone,role,created_at FROM users ORDER BY created_at DESC LIMIT 200`).all());
});
app.get('/api/admin/businesses',auth,role('admin'),(req,res)=>{
  res.json(q(`SELECT b.*,u.name owner_name,u.email owner_email FROM businesses b JOIN users u ON u.id=b.owner_id ORDER BY b.created_at DESC LIMIT 200`).all());
});
app.patch('/api/admin/businesses/:id/verify',auth,role('admin'),(req,res)=>{
  const verified=Number(req.body.verified)?1:0;
  const b=q('SELECT b.*,u.name owner_name FROM businesses b JOIN users u ON u.id=b.owner_id WHERE b.id=?').get(req.params.id);
  if(!b)return res.status(404).json({error:'Business not found'});
  q('UPDATE businesses SET verified=? WHERE id=?').run(verified,b.id);
  notify(b.owner_id,'verification',verified?'Business verified':'Verification removed',verified?'Your business has been verified by the marketplace admin.':'Your business verification has been removed.',`provider.html?id=${b.id}`);
  res.json({ok:true,verified});
});
app.get('/api/admin/bookings',auth,role('admin'),(req,res)=>{
  res.json(q(`SELECT b.id,b.status,b.scheduled_at,b.created_at,r.title,cu.name customer_name,biz.name business_name,q.amount,p.status payment_status,p.reference
    FROM bookings b JOIN requests r ON r.id=b.request_id JOIN users cu ON cu.id=b.customer_id JOIN businesses biz ON biz.id=b.business_id JOIN quotes q ON q.id=b.quote_id
    LEFT JOIN payments p ON p.booking_id=b.id ORDER BY b.created_at DESC LIMIT 200`).all());
});
app.get('/api/admin/payments',auth,role('admin'),(req,res)=>{
  res.json(q(`SELECT p.*,cu.name customer_name,biz.name business_name,r.title FROM payments p JOIN users cu ON cu.id=p.customer_id JOIN businesses biz ON biz.id=p.business_id JOIN bookings b ON b.id=p.booking_id JOIN requests r ON r.id=b.request_id ORDER BY p.created_at DESC LIMIT 200`).all());
});
app.get('/api/admin/reviews',auth,role('admin'),(req,res)=>{
  res.json(q(`SELECT rv.*,cu.name customer_name,biz.name business_name,r.title FROM reviews rv JOIN users cu ON cu.id=rv.customer_id JOIN businesses biz ON biz.id=rv.business_id JOIN bookings b ON b.id=rv.booking_id JOIN requests r ON r.id=b.request_id ORDER BY rv.created_at DESC LIMIT 200`).all());
});

app.get('/api/categories',(_,res)=>res.json(['Fridge Repair','AC Repair','Plumbing','Electrical','Generator Repair','Cleaning','Painting','Phone Repair','Computer Repair','Car Repair','Moving Services','Beauty Services']));
if(process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD){
  if(String(process.env.ADMIN_PASSWORD).length<12) console.warn('WARNING: ADMIN_PASSWORD should be at least 12 characters in production.');
  const adminEmail=normalizeEmail(process.env.ADMIN_EMAIL);
  const existing=q('SELECT id FROM users WHERE email=?').get(adminEmail);
  if(!existing) q('INSERT INTO users(role,name,email,password_hash) VALUES(?,?,?,?)').run('admin',process.env.ADMIN_NAME||'Marketplace Admin',adminEmail,hashPassword(process.env.ADMIN_PASSWORD));
}
const port=Number(process.env.PORT||3000);
if(isProduction && !process.env.PAYSTACK_SECRET_KEY) console.warn('WARNING: PAYSTACK_SECRET_KEY is not configured.');
if(isProduction && !process.env.PUBLIC_BASE_URL) console.warn('WARNING: PUBLIC_BASE_URL is not configured.');
function notify(userId,type,title,body,link=null){
  q(`INSERT INTO notifications(user_id,type,title,body,link) VALUES(?,?,?,?,?)`).run(userId,type,title,body,link);
}
app.get('/api/conversations',auth,(req,res)=>{
  const rows=q(`SELECT c.id,c.request_id,
    CASE WHEN c.customer_id=? THEN p.name ELSE cu.name END other_name,
    CASE WHEN c.customer_id=? THEN c.provider_id ELSE c.customer_id END other_user_id,
    (SELECT body FROM messages m WHERE m.conversation_id=c.id ORDER BY m.created_at DESC LIMIT 1) last_message,
    (SELECT COUNT(*) FROM messages m WHERE m.conversation_id=c.id AND m.sender_id<>? AND m.read_at IS NULL) unread_count
    FROM conversations c
    JOIN users cu ON cu.id=c.customer_id JOIN users p ON p.id=c.provider_id
    WHERE c.customer_id=? OR c.provider_id=? ORDER BY c.created_at DESC`)
    .all(req.user.id,req.user.id,req.user.id,req.user.id,req.user.id);
  res.json(rows);
});
app.post('/api/conversations',auth,(req,res)=>{
  const {provider_id,request_id}=req.body;
  let provider=Number(provider_id);
  if(req.user.role==='provider') provider=req.user.id;
  if(!provider)return res.status(400).json({error:'Provider is required'});
  const prov=q("SELECT id,role FROM users WHERE id=?").get(provider);
  if(!prov||prov.role!=='provider')return res.status(404).json({error:'Provider not found'});
  const customer=req.user.role==='customer'?req.user.id:Number(req.body.customer_id);
  if(!customer)return res.status(400).json({error:'Customer is required'});
  let c=q(`SELECT * FROM conversations WHERE customer_id=? AND provider_id=? AND request_id IS ?`).get(customer,provider,request_id??null);
  if(!c){
    const info=q(`INSERT INTO conversations(customer_id,provider_id,request_id) VALUES(?,?,?)`).run(customer,provider,request_id??null);
    c=q('SELECT * FROM conversations WHERE id=?').get(info.lastInsertRowid);
  }
  res.status(201).json(c);
});
app.get('/api/conversations/:id/messages',auth,(req,res)=>{
  const c=q('SELECT * FROM conversations WHERE id=?').get(req.params.id);
  if(!c)return res.status(404).json({error:'Conversation not found'});
  if(c.customer_id!==req.user.id && c.provider_id!==req.user.id)return res.status(403).json({error:'Forbidden'});
  q(`UPDATE messages SET read_at=CURRENT_TIMESTAMP WHERE conversation_id=? AND sender_id<>? AND read_at IS NULL`).run(c.id,req.user.id);
  res.json(q(`SELECT m.*,u.name sender_name FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.conversation_id=? ORDER BY m.created_at ASC`).all(c.id));
});
app.post('/api/conversations/:id/messages',auth,(req,res)=>{
  const c=q('SELECT * FROM conversations WHERE id=?').get(req.params.id);
  if(!c)return res.status(404).json({error:'Conversation not found'});
  if(c.customer_id!==req.user.id && c.provider_id!==req.user.id)return res.status(403).json({error:'Forbidden'});
  const body=String(req.body.body||'').trim();
  if(!body)return res.status(400).json({error:'Message cannot be empty'});
  const info=q(`INSERT INTO messages(conversation_id,sender_id,body) VALUES(?,?,?)`).run(c.id,req.user.id,body);
  const recipient=req.user.id===c.customer_id?c.provider_id:c.customer_id;
  notify(recipient,'message','New message',`${req.user.name}: ${body}`.slice(0,240),`messages.html?conversation=${c.id}`);
  res.status(201).json(q(`SELECT m.*,u.name sender_name FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id=?`).get(info.lastInsertRowid));
});
app.get('/api/notifications',auth,(req,res)=>{
  res.json(q(`SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100`).all(req.user.id));
});
app.post('/api/notifications/:id/read',auth,(req,res)=>{
  const n=q('SELECT * FROM notifications WHERE id=? AND user_id=?').get(req.params.id,req.user.id);
  if(!n)return res.status(404).json({error:'Notification not found'});
  q(`UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE id=?`).run(n.id);
  res.json({ok:true});
});
app.post('/api/notifications/read-all',auth,(req,res)=>{
  q(`UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE user_id=? AND read_at IS NULL`).run(req.user.id);
  res.json({ok:true});
});

app.listen(port,()=>console.log(`Project Marketplace API running on http://localhost:${port}`));
